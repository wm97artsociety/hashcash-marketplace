# Hash Cash Token (HC) Full Project

This project includes:
- HC Marketplace APK
- Free listings marketplace (Firebase)
- Penny-based HC token value model
- Laddered buy/sell fee tiers
- Dip Stop & Buy Go mechanisms
- Hashcash miner integration (17 difficulty)

🔧 To set your admin wallet, edit `wallet/config.js`.
🔧 For block time and difficulty, see `blockchain/value-model.js`.